import React from 'react'
import './testimonials.css'

function Testimonials() {
  return (
    <section id='testimonials'>Testimonials</section>
  )
}

export default Testimonials